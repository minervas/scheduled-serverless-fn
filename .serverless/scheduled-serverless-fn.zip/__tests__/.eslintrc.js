module.exports = {
  env: {
    jest: true,
    node: true
  },
  extends: 'airbnb',
};
