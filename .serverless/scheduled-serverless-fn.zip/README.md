Scheduling Recurring Code Execution Through Serverless Framework
================================================================

Motivation
----------

Running code on a regular interval is a pretty common task in software development. 
The first impulse for many developers that need to accomplish such a task is to start writing 
a script of a language of their choice and then scheduling execution via the commandline tool, 
`cron`. Then, once the script gains uptime requirements, web hosting, daemonization, scaling, and 
continuous deployment all become concerns. These supporting tasks may end up becoming more work 
than coding up the actual work you are trying to get done in the first place.

Fortunately, the big players in cloud computing services have solutions aimed at reducing the
boiler-plate involved in running code in the cloud. These solutions are commonly referred to
as `Serverless`. Serverless is one step beyond traditional PaaS offerings. With Severless you code 
takes minimal time to "spin up" for the first time, only runs when invoked, is typically 
cheaper than persistent servers when those servers are underutilized, autoscales, and requires less 
deployment environment configuration than with most PaaS setups.

As Serverless services are a relatively new avenue of cloud code execution, there is not a widely 
used standard for shaping your serverless project. There is, however, a few frameworks focused on 
abstracting away the differences between Serverless cloud providers. Using one of these frameworks 
helps mitigate vendor lock-in.

Setup
-------

This post will use the [Serverless Framework](https://serverless.com/) to deploy an [AWS Lambda](https://aws.amazon.com/lambda/) function that executes Node.js code on a schedule.

Make sure you [install Node.js](https://nodejs.org/en/download/package-manager/) and set up [AWS credentials](https://serverless.com/framework/docs/providers/aws/guide/credentials/) for your development environment. Commands in this tutorial will use the [npx commandline utility](https://www.npmjs.com/package/npx) which was introduced with `npm` version 5.2.0.

Code
-----

Feel free to download and modify the [git hub project](https://github.com/minervas/scheduled-serverless-fn) for this tutorial.

All serverless framework projects start with a simple `serverless.yml` file that contains basic 
configuration for your project.

```YAML
# name your project here
service: scheduled-serverless-fn

# config relavent to the cloud provider that will run your serverless function
provider:
  # we will use AWS for this tutorial, but check out the list of all supported providers here:
  # https://serverless.com/framework/docs/providers/
  name: aws
  # this example is coded in node.js but check out all the supported aws lambda runtimes here:
  # https://docs.aws.amazon.com/lambda/latest/dg/lambda-runtimes.html
  runtime: nodejs8.10

# config for all the functions that make up your service
functions:
  # the name of your function
  scheduleFunction:
    # {{path to the script containing the entrypoint of your function}}.{{the entrypoint function name}}
    handler: entrypoint.scheduleFunction
    # config for what sort of events trigger your function
    events:
      # invoke our function on the first minute of every even 15 minute interval
      # check out
      # https://docs.aws.amazon.com/lambda/latest/dg/tutorial-scheduled-events-schedule-expressions.html
      # for AWS cron syntax
      - schedule: cron(0/15 * * * ? *)
```

After creating this configuration you'll want to create the entry point of your function, I named 
mine `entrypoint.js`. Note, exported `scheduleFunction` whos name matches the handler function 
name in our `serverless.yml`

```javascript
// the class that contains task logic to accomplish our goals
const ScheduleWorker = require('./ScheduleWorker');
// instantiate the class
const scheduleWorker = new ScheduleWorker();

// start setting up resources that will persist between serverless invocations
const persistantResourcesReady = scheduleWorker.setupPersistentResources();

module.exports.scheduleFunction = async () => {
  // wait for persist
  await persistantResourcesReady;
  // check if any persistent resources expired between invocations
  await scheduleWorker.refreshResources();
  // set up resources that should only exist during the function invocation
  await scheduleWorker.setupEphemeralResources();
  // complete the scheduled task
  await scheduleWorker.doWork();
  // clean up resources that should only exist during the function invocation
  await scheduleWorker.cleanUpResources();
};
```